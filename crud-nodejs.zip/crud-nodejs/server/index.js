import express from "express"
import mongoose from "mongoose"
import bodyParser from "body-parser"
import dotenv  from "dotenv";
import cors from "cors";
import { ApiError } from "./ApiError.utils.js";

import { Student } from "./student.model.js";

const app = express();
app.set("view engine", "ejs");
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));
app.use(express.json());
app.use(cors({
    origin:"*",
    credentials:true
}))

dotenv.config({
    path:".env"
});


const connectDB = async () => {

    try {
        const connectionInstance = await mongoose.connect(`${process.env.MONGODB_URI}`)
        console.log("DB connected with host id : ",connectionInstance.connection.host);
    }
    catch (err) {
        console.log(err);
        process.exit(1);
    }
}

connectDB();

app.get("/",(req,res)=>{

    res.render("landingpage.ejs");

});

app.post("/register", async (req,res) => {

    const {name,rollno,wad_mrk,cc_mrk,dsbda_mrk,cns_mrk,ai_mrk} = req.body;

    console.log("req body : ",req.body);

    if(
        [name].some(
            (field) => field.trim() === ""
        )
    ) {
        console.log("all fields are compulsary ! ");
        throw new ApiError(500,"All fields are compulsary ! ");
    }

    const ispresent = await Student.findOne({rollno});

    if(ispresent) {
        throw new ApiError(300,"Student with this roll no already exists ! ");
    }

    const createdStudent = Student.create({
        name,
        rollno,
        wad_marks:wad_mrk,
        cc_marks:cc_mrk,
        dsbda_marks:dsbda_mrk,
        cns_marks:cns_mrk,
        ai_marks:ai_mrk
    })

    res.redirect("/displayintabular")

    // return res.status(200).json({ message: "Student added successfully", data: createdStudent });

});

app.post("/update", async(req,res) => {

    const {rollno} = req.body;
    console.log("req body : ",req.body);

    if(!rollno) throw new ApiError(500,"all fields are compulsary ! ");

    const requiredStudent = await Student.findOne({rollno:rollno});

    console.log("required student : ",requiredStudent);

    if(!requiredStudent) throw new ApiError(404,`Student with roll no ${rollno} not found ! `);

    const wad_mrks = requiredStudent.wad_marks + 10;
    const cc_mrks = requiredStudent.cc_marks + 10;
    const dsbda_mrks = requiredStudent.dsbda_marks + 10;
    const cns_mrks = requiredStudent.cns_marks + 10;
    const ai_mrks = requiredStudent.ai_marks + 10;


    const updatedStudent = await Student.findByIdAndUpdate(
        requiredStudent._id,
        {
            wad_marks:wad_mrks,
            cc_marks:cc_mrks,
            dsbda_marks:dsbda_mrks,
            cns_marks:cns_mrks,
            ai_marks:ai_mrks,
        },
        {
            new:true
        }
    );

    res.redirect("/displayintabular");
    // return res.status(200).json(`Student details updated : ${updatedStudent}`);

});

app.get("/dsbdamorethan20", async(req,res) => {

    const students = await Student.find({dsbda_marks: { $gt:39 } });

    console.log("students are : ",students);

    res.render("tabular.ejs", { student: students } );
    // return res.status(200).json("students found");

})

app.get("/greaterthan25inall", async(req,res) => {

    const students = await Student.find( { dsbda_marks: { $gt:25 }  , wad_marks: { $gt:25 } } );

    console.log("Students are : ",students);

    res.render("tabular.ejs", { student: students } );

    // return res.status(200).json("students Found");
})


app.post("/deleteStudent", async(req,res) => {

    const {rollno} = req.body;

    await Student.deleteOne({rollno:rollno});

    res.redirect("/displayintabular");
    // return res.status(200).json("student deleted SuccessFully !! ");

})

app.get("/displayintabular", async(req,res) => {

    const students = await Student.find();

    console.log("students found ",students);

    // return res.status(200).json("students found !! ");

    res.render("tabular.ejs", { student: students } );

})


const port = process.env.PORT || 4000;

app.listen(port,(req,res) => {
    console.log(`server listening on port ${port}`);
})